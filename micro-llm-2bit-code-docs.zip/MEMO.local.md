# MÉMO — micro-llm-2bit (note de passage pour les sessions futures)

## C'est quoi
Petit LLM ternaire 2 bits (BitNet b1.58), decoder-only tiny
(V=8000, d=512, L=8, Hq=8, Hkv=4, ffn=1024, ~23M params, ~18 Mo < 100 Mo),
inférence CPU via noyau C NEON (`.dylib` + ctypes), entraîné par distillation
KL depuis `HuggingFaceTB/SmolLM-360M`. CLI : `infer / train / export / bench /
distill-loop` (`python main.py <cmd> --help`).

## Toolchain (ne pas changer)
- `mise` = Python 3.11 uniquement (`.mise.toml`), `uv` = venv + deps
  (`pyproject.toml` + `uv.lock`). Poetry écarté, cargo hors sujet.
- `make` compile `kernels/neon.c` (arm64) vers `build/libmicro2bit.dylib`
  (clang Apple, GCD, pas d'OpenMP). Fallbacks : `avx2.c`, `portable.c`, NumPy.
- Fichiers : `quant.py` (ternaire + packing), `model.py` (Transformer + budget),
  `engine.py` (infer C/NumPy + `.bin`), `data.py` (corpus + vocab réduit),
  `distill.py` (KL + boucle train + pont Ollama), `main.py` (CLI).

## Recette qui marche (ordre exact)
```bash
cd ~/micro-llm-2bit && uv run python main.py train --data <dirs...> \
  --parent HuggingFaceTB/SmolLM-360M --out checkpoints/enfant.pt --epochs 3
uv run python main.py export --ckpt checkpoints/enfant.pt --out exports/enfant.bin
uv run python main.py bench --model exports/enfant.bin --bench-tokens 32
uv run python main.py infer --model exports/enfant.bin --prompt "..." --max-new 60
```

## Corpus du disque externe
`/Volumes/dique secours/rag-data` (47 Mo). Tri effectué :
- GARDÉS : `wiki/` (fr), `monde/` (fiches pays), `internet/` (stackexchange en),
  `actu/` (RSS Le Monde/BBC via support `.xml` ajouté à `data.py`), `rfc/` (en).
  = 297 docs, 1.7M caractères.
- EXCLUS : `cuisine/` (pages d'erreur HTML), `france/`+`livres/` (métadonnées),
  `monde_src/` (code), `pdf/` (datasheets en).
- `--data` accepte plusieurs chemins (`nargs="+"`, cf. `main.py` + `data.py`).

## Bug déjà corrigé (ne pas réintroduire)
`DistillationLoss` utilisait `F.kl_div(..., reduction="batchmean")` qui ne
divise que par B (pas B×S) → KL ~128× trop grande (loss ~789). Fix :
`(t_prob * (t_prob.log() - s_logp)).sum(-1).mean() * T²`. Repère : à step 20,
loss ~8, CE ~7 (< hasard ln(8000)=8.99). Test numérique inline + 15 tests pytest.

## Ollama / Mac mini distant
- Serveur : `http://100.101.108.111:11434` (mini, Tailscale). Modèle juge :
  `smollm2:360m` (`ollama pull` **sur le mini**).
- Le client Python lit `OLLAMA_HOST` (vérifié dans `ollama/_client.py`) :
  `export OLLAMA_HOST=http://100.101.108.111:11434` avant `distill-loop`.
- IMPORTANT : Ollama ne sert QUE pour `distill-loop` (texte). Le `train` KL
  exige le parent HF en local (logits) et tourne à 100 % sur le Mac principal
  (MPS). ~639 steps ≈ 20-40 min pour le corpus 1.7M.

## GitHub
Repo : `dimitricl/micro-llm-2bit`. Ne jamais committer : `.venv/`,
`*.pt`, `*.bin`, `~/.cache/huggingface` (déjà dans `.gitignore`).
Pour runner sur le mini : `git clone`, `mise install`, `uv sync`, `make`,
mêmes commandes (adapter `--data` au chemin local du corpus).

## Disques + corpus FR (8 oct 2026)
- `rag-data` copié de `/Volumes/dique secours/rag-data` vers
  `/Volumes/Lexar/rag-data` (47 Mo, `diff -rq` OK) ; « dique secours »
  éjecté. Utiliser désormais `--data /Volumes/Lexar/rag-data/...`.
- Corpus FR propre : `wiki/` (33 docs, 391k chars) +
  `data_clean/monde_fr.txt` (245 phrases `X est un pays d'Y dont la
  capitale est Z`, générées depuis `monde/`). EXCLUS : `rfc/` (anglais,
  69 % du corpus), `monde/` brut (stubs ~73 chars), `actu/` (boilerplate
  RSS), `internet/` (anglais).
- Audit : l'ancien mix faisait sortir « fréquence/échantillonnage » en
  boucle (vocab RFC). Après switch FR : CE ~0.7-1.3, PPL ~2-4.
- Checkpoints base = 843 Mo/pièce (poids fp32 + 2 moments AdamW) :
  ne garder que les 1-2 derniers (`rm` des `_e*.pt` intermédiaires).
  Crash disque-plein déjà vu une fois (écriture tronquée e28).
- Projet DÉMÉNAGÉ sur `/Volumes/Lexar/micro-llm-2bit` (8 oct, session
  basculée) : venv recréé (`uv venv` + `uv sync`, Python 3.11.15,
  torch 2.14.1), dylib recompilé (`make`). Traces think relancées
  depuis ici. L'ancien dossier interne ne sert plus.
- Run en cours : `checkpoints/enfant_base_fr.pt` (config base, vocab
  12000, seq 256, 40 epochs, hidden 0.2, reprise depuis
  `enfant_base_fr_e27.pt` step 840/1200).
- RÉSULTAT (8 oct, ~07h40) : 1200 steps, CE 0.59, PPL 1.8.
  `exports/enfant_base_fr.bin` 28 Mo, bench 30.2 Mo/100 Mo OK, 41 tok/s.
  Pattern pays parfait (« X est un pays ... dont la capitale est Y »),
  français libre = syntaxe par fragments mais pas de sens suivi
  (corpus 400k chars trop petit pour plus). Intermédiaires purgés, seul
  le `.pt` final gardé. Prochaine étape si besoin : corpus FR plus gros.
- LOT 1 Go + think (8 oct) : `data_fetch/fetch_wiki.py` stream Wikipedia
  FR vers `/Volumes/Lexar/clean-corpus/wiki_fr.jsonl` (cible 1 Go).
  `data_fetch/gen_think.py` génère traces `<think>` via Ollama
  (`THINK_MODEL=phi4-mini`, 250 traces pays puis wiki).
  Retrain think LANCÉ (Lexar) : `checkpoints/enfant_think.pt`, from
  scratch, tranche wiki 100 Mo (5141 docs) + 250 traces pays + 236
  traces wiki + monde_fr, 2 epochs (~4-5h), pipeline auto
  (`pipeline_think.sh` : export/bench/infer avec prompt think).
  NOTE : 1 Go ~= 250M tokens ; à ~750 tok/s (micro-batch, parent inclus),
  une epoch d'une tranche 100 Mo ~= 6500 micro-steps ~= 10h. Le Go est un
  réservoir : un pass complet (10 tranches x 1 epoch) ~= 100h. Pré-calculer
  les logits parent (top_k_cache) ou réduire le parent pour aller plus vite.
- Tâches 1-4 (8 oct, session Lexar) :
  - T1 mémoire : engine.py en memmap zéro-copie + logits par blocs
    (6 Mo vs 37 Mo) + buffers préalloués. bench base FR : chargement
    +85 -> +0.5 Mo, delta après génération +159 -> +51 Mo (< 100 OK).
    Greedy bit-identique, tests/test_rss.py (delta, golden, C-vs-NumPy).
  - T2 val : data.train_val_split (5 %, seed fixe), --val-ratio,
    --eval-every, --patience, best-val sans optimiseur, tableau
    train-PPL vs val-PPL + alerte surapprentissage (> 1.5x).
  - T4 corpus : data_clean/make_monde_fr.py (tables FR, 245 phrases,
    5 sans capitale listées dans monde_missing.txt, jamais inventées).
    Diagnostic think : pays ratee = client Ollama qui parse <think>
    comme tool-call (gpt-oss, hyp. b) ; wiki 58 ignoree = 56 réponses
    vides fin de run (serveur fatigué, hyp. c) + 2 sans balises, pas
    de troncature num_predict (hyp. a rejetée). gen_think.py : parsing
    strict, 1 relance ciblée, validation (FR, longueurs, attendu),
    rejetés à part. clean_think.py -> *.clean.jsonl + q_wiki_retry.
    Modèle Ollama qui rendait vide réparé (unload/reload phi4-mini).
  - T3 tranches : data_fetch/make_slices.py (hash déterministe, .jsonl),
    --vocab-from, refus si vocab != checkpoint, --lr-resume,
    --rewarmup-ratio, data_fetch/run_slices.sh (estimation + --go).
  - NaN think : OOM GPU du mini (M4) avec base+hidden+seq256 -> run tué,
    relance à valider avec batch-size 1 / seq 128 / sans hidden.
- Brief bench-train (code écrit, mesures en attente : GPU occupé par
  mini_test + thinks) : `tools/bench_train.py` (profil par étape sync
  MPS, matrice tiny/base x 135M/360M x bs 2/4/8/16 avec skip OOM,
  autocast bf16/fp16 + finitude, comparaison cache top-32 vs direct)
  -> `tools/bench_train.md`. Cache refondu (mmap fp16/u16 + manifeste,
  index (batch,chunk) ; ancien npz abandonné car faux sous mélange).
  `--cache-k` (32), garde-fou `*_nonfinite.pt`. Test 135M = même
  tokenizer que 360M. En attente du signal pour mesurer.
- ANOMALIE CACHE (à investiguer, ne pas toucher pendant le run) :
  valCE direct 0.80 (PPL 2.2) vs k32 1.14 (3.1) vs k64 1.06 (2.9),
  écart valeurs +86 %/+17 %. Hypothèses : renormalisation de la KL
  tronquée (objectif structurellement différent), logits fp16,
  température avant/après le top-k, mapping kept_ids.
- Phase 3 (sans GPU) : tools/eval_fixed.py (20 prompts, eval/mini),
  tools/eval_ppl.py (PPL .bin + anti-fuite), tools/plot_run.py +
  tools/runs_table.py (-> docs/RUNS.md), matplotlib en dev-dep.
  Fix moteur : generate() s'arrête à capacité (KV fixe, plus de
  dépassement seq_max). Reprise best-val (sans opt) supportée +
  testée (--lr-resume/--rewarmup-ratio).
- Séquence run tranche (en préparation) : `cache-logits` (nouveau :
  même prepare_corpus que train, caches train+val mmap, vérif
  micro-batch au chargement, nom parent explicite dans le manifeste),
  25/25 tests verts. En attente : fin mini_test (veilleur armé).
